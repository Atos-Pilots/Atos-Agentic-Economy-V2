import { sagaOrchestrator } from './services/saga.orchestrator';
import { app } from './gateway/gateway';
import { agentRegistry } from './services/agent.registry';
import { merchantAgent } from './agents/merchant.agent';
import { flightMerchantAgent } from './agents/flight.merchant.agent';
import { receiptEngine } from './services/receipt.engine';

const PORT = process.env.PORT || 3000;

// Register the agents in the ecosystem
agentRegistry.registerAgent({
    agent_id: merchantAgent.agentId,
    agent_name: merchantAgent.agentName,
    description: 'Sephora UCP Agent Simulator',
    security_metadata: { did: 'did:web:sephora.fake', endpoint_url: 'http://localhost:3000/v1/ucp' },
    exposed_capabilities: ['ucp.search', 'ucp.checkout'],
    protocol_versions: ['1.0.0'],
    trust_policies: { requires_sca: true, allowed_rails: ['SEPA', 'STABLECOIN_EURC'] },
    status: 'ACTIVE'
});

agentRegistry.registerAgent({
    agent_id: flightMerchantAgent.agentId,
    agent_name: flightMerchantAgent.agentName,
    description: 'AirFrance UCP Flight Agent',
    security_metadata: { did: 'did:web:airfrance.fake', endpoint_url: 'http://localhost:3000/v1/ucp' },
    exposed_capabilities: ['ucp.search', 'ucp.checkout'],
    protocol_versions: ['1.0.0'],
    trust_policies: { requires_sca: true, allowed_rails: ['SEPA'] },
    status: 'ACTIVE'
});

app.listen(PORT, () => {
  console.log(`[Server] Antigravity Agentic Payment Node listening on port ${PORT}`);
  console.log(`[Saga Orchestrator] Init. Is active? ${!!sagaOrchestrator}`);
});
