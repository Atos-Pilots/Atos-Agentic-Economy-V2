import { UcpOffer } from './personal.agent';

export class FlightMerchantAgent {
    public readonly agentId = 'mch_travel_af_ai';
    public readonly agentName = 'AirFrance UCP Agent';

    // Mock Flight Catalog Data (Simulating a GDS/booking engine response)
    private flightCatalog = [
        { id: 'fl_cdg_jfk_1', category: 'urn:atos:pilot:travel:flight', name: 'Flight CDG -> JFK (Economy)', price: 450.00, availableSeats: 12, layovers: 0 },
        { id: 'fl_cdg_jfk_2', category: 'urn:atos:pilot:travel:flight', name: 'Flight CDG -> JFK (Business)', price: 1850.00, availableSeats: 3, layovers: 0 },
        { id: 'fl_lhr_dxb_1', category: 'urn:atos:pilot:travel:flight', name: 'Flight LHR -> DXB', price: 320.00, availableSeats: 45, layovers: 1 }
    ];

    /**
     * UCP Search evaluation
     */
    public async evaluateSearch(category: string): Promise<UcpOffer[]> {
        console.log(`[Merchant Agent: ${this.agentName}] Evaluating travel search for category: ${category}`);
        
        const matches = this.flightCatalog.filter(item => item.category === category && item.availableSeats > 0);

        return matches.map(m => ({
            offer_id: `off_${Date.now()}_${m.id}`,
            merchant_id: this.agentId,
            item_description: m.name,
            price: m.price,
            currency: 'EUR',
            estimated_delivery_days: m.layovers // For flights, delivery days could map to layovers or duration loosely for the basic deterministic scoring
        }));
    }

    /**
     * UCP Order Prepare / Checkout
     */
    public async prepareCheckout(offerId: string, constraints: any): Promise<{ checkout_id: string, total: number }> {
        console.log(`[Merchant Agent: ${this.agentName}] Preparing flight booking checkout for offer ${offerId}...`);
        
        return {
            checkout_id: `chk_flight_${Date.now()}`,
            total: 450.00 // Assuming simple mock match
        };
    }
}

export const flightMerchantAgent = new FlightMerchantAgent();
