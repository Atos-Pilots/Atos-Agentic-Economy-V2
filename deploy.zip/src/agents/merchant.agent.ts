import { UcpOffer } from './personal.agent';

export class MerchantAgent {
    public readonly agentId = 'mch_lv_sephora_ai';
    public readonly agentName = 'Sephora AI Agent';

    // Mock Catalog
    private catalog = [
        { id: 'item_101', category: 'urn:atos:pilot:retail:perfume', name: 'Chanel No. 5 Eau de Parfum 50ml', price: 125.00, inStock: true, deliveryDays: 2 },
        { id: 'item_102', category: 'urn:atos:pilot:retail:perfume', name: 'Sauvage Dior 100ml', price: 110.00, inStock: true, deliveryDays: 1 },
        { id: 'item_103', category: 'urn:atos:pilot:retail:perfume', name: 'Premium Perfume Collection', price: 280.00, inStock: false, deliveryDays: 5 }
    ];

    /**
     * UCP Search evaluation
     */
    public async evaluateSearch(category: string): Promise<UcpOffer[]> {
        console.log(`[Merchant Agent: ${this.agentName}] Evaluating search for category: ${category}`);
        
        const matches = this.catalog.filter(item => item.category === category && item.inStock);

        return matches.map(m => ({
            offer_id: `off_${Date.now()}_${m.id}`,
            merchant_id: this.agentId,
            item_description: m.name,
            price: m.price,
            currency: 'EUR',
            estimated_delivery_days: m.deliveryDays
        }));
    }

    /**
     * UCP Order Prepare / Checkout
     * Data Minimization: We only receive exactly what is needed for checkout, nothing more.
     */
    public async prepareCheckout(offerId: string, constraints: any): Promise<{ checkout_id: string, total: number }> {
        console.log(`[Merchant Agent: ${this.agentName}] Preparing checkout for offer ${offerId}...`);
        
        // Very basic mock
        return {
            checkout_id: `chk_${Date.now()}`,
            total: 100.00 // Assuming it matches the offer
        };
    }
}

export const merchantAgent = new MerchantAgent();
