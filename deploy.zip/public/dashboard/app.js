// State
let stats = {
    intents: 0,
    purchases: 0,
    searchTimestamps: {}
};

// Dom Elements
const logContainer = document.getElementById('event-log');
const elIntents = document.getElementById('kpi-intents');
const elPurchases = document.getElementById('kpi-purchases');
const elTime = document.getElementById('kpi-time');

function clearLog() {
    logContainer.innerHTML = '';
}

function updateTopology(type) {
    const nodes = document.querySelectorAll('.node');
    nodes.forEach(n => n.classList.remove('active'));

    if(type.startsWith('wallet')) {
        document.getElementById('node-wallet').classList.add('active');
    } else if(type.startsWith('search') || type.startsWith('offer') || type === 'intent.captured') {
        document.getElementById('node-pa').classList.add('active');
        document.getElementById('node-sephora').classList.add('active');
        document.getElementById('node-af').classList.add('active');
    } else if(type.startsWith('payment') || type === 'merchant.order.confirmed') {
        document.getElementById('node-ledger').classList.add('active');
    } else if(type === 'purchase.completed') {
        document.getElementById('node-wallet').classList.add('active');
        document.getElementById('node-pa').classList.add('active');
        document.getElementById('node-ledger').classList.add('active');
    }
}

function calculateKPIs(type, payload, timestamp) {
    const now = new Date(timestamp).getTime();
    
    if(type === 'intent.captured') {
        stats.intents++;
        elIntents.innerText = stats.intents;
        // Tracking start of search
        if(payload.intent_id) stats.searchTimestamps[payload.intent_id] = now;
    }

    if(type === 'offer.selected') {
        // Search ends
        if(payload.intent_id && stats.searchTimestamps[payload.intent_id]) {
            const diff = now - stats.searchTimestamps[payload.intent_id];
            elTime.innerText = diff + ' ms';
        }
    }

    if(type === 'purchase.completed') {
        stats.purchases++;
        elPurchases.innerText = stats.purchases;
    }
}

function appendEvent(type, payload, timestamp) {
    const item = document.createElement('div');
    item.className = 'event-item';
    item.setAttribute('data-type', type);
    
    const timeStr = new Date(timestamp).toLocaleTimeString();
    
    item.innerHTML = `
        <div class="event-header">
            <span class="event-type">${type}</span>
            <span class="event-time">${timeStr}</span>
        </div>
        <div class="event-payload">${JSON.stringify(payload, null, 2)}</div>
    `;
    
    logContainer.appendChild(item);
    logContainer.scrollTop = logContainer.scrollHeight;
}

// Connect to SSE
const source = new EventSource('/v1/telemetry/stream');

source.onopen = () => {
    appendEvent('SYS', { message: 'Successfully connected to Stream' }, new Date().toISOString());
};

source.onmessage = (event) => {
    const data = JSON.parse(event.data);
    
    appendEvent(data.type, data.payload, data.timestamp);
    updateTopology(data.type);
    calculateKPIs(data.type, data.payload, data.timestamp);
};

source.onerror = (err) => {
    console.error('SSE Error', err);
};
