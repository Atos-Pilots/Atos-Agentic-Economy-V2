import { eventBus } from '../services/event.bus';
import { agentRegistry } from '../services/agent.registry';
import { policyEngine } from '../services/policy.engine';
import { AuthorizedRail } from '../models/types';
import axios from 'axios';

export interface PurchaseIntent {
    user_id: string;
    product_category: string;
    target_budget: number;
    currency: string;
    hard_constraints?: {
        max_delivery_days?: number;
    };
}

export interface UcpOffer {
    offer_id: string;
    merchant_id: string;
    item_description: string;
    price: number;
    currency: string;
    estimated_delivery_days: number;
}

export interface ProposalReviewState {
    proposal_id: string;
    intent: PurchaseIntent;
    mandate_id: string;
    selected_offer: UcpOffer;
    suggested_rail: string;
    status: 'user_review_pending' | 'review_approved' | 'rejected';
}

export class PersonalAgent {
    public pendingProposals: Map<string, ProposalReviewState> = new Map();

    public async captureAndProcessIntent(intent: PurchaseIntent, sdJwtMandateId: string): Promise<ProposalReviewState | null> {
        console.log(`[Personal Agent] Captured purchase intent for: ${intent.product_category}`);
        eventBus.publish('intent.captured', intent);

        const mandateCheck = await policyEngine.evaluateExecution(sdJwtMandateId, 0, AuthorizedRail.SEPA);
        if (!mandateCheck.allowed && mandateCheck.reason?.includes('REVOKED')) {
            throw new Error(`[Personal Agent] ABORT: Security Mandate is invalid or revoked. Access Denied.`);
        }

        eventBus.publish('search.started', { category: intent.product_category });
        const merchants = agentRegistry.discoverByCapability('ucp.search');
        
        const offersResponses = await Promise.allSettled(
           merchants.map(merchant => this.queryMerchant(merchant.agent_id, intent))
        );

        let validOffers: UcpOffer[] = [];
        offersResponses.forEach(res => {
            if (res.status === 'fulfilled' && res.value) {
                validOffers = validOffers.concat(res.value);
            }
        });

        eventBus.publish('offers.received', { offer_count: validOffers.length });

        const bestOffer = this.scoreAndSelectOffer(validOffers, intent);
        if (!bestOffer) {
            console.error(`[Personal Agent] ABORT: No offers matched constraints for budget ${intent.target_budget}. Intent dissolved.`);
            eventBus.publish('search.failed', {
                intent,
                reason: 'NO_ELIGIBLE_OFFERS'
            });
            return null;
        }

        eventBus.publish('offer.selected', bestOffer);

        // Transition logic to Review State instead of immediate AP2 checkout!
        const proposal: ProposalReviewState = {
            proposal_id: `prop_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
            intent,
            mandate_id: sdJwtMandateId,
            selected_offer: bestOffer,
            suggested_rail: AuthorizedRail.STABLECOIN_EURC, // AI default optimization
            status: 'user_review_pending'
        };

        this.pendingProposals.set(proposal.proposal_id, proposal);
        console.log(`[Personal Agent] Proposal ${proposal.proposal_id} blocked at status: user_review_pending`);

        return proposal;
    }

    private async queryMerchant(merchantId: string, intent: PurchaseIntent): Promise<UcpOffer[]> {
        console.log(`[Personal Agent] Querying Merchant via UCP A2A: ${merchantId}`);
        try {
            const response = await axios.post('http://localhost:3000/v1/ucp/search', {
                category: intent.product_category,
                merchant_id: merchantId
            });
            return response.data.offers as UcpOffer[];
        } catch (e: any) {
            if (e.response && e.response.status === 402) {
                console.log(`[Personal Agent] ⚠️ Handshake Blocked: HTTP 402 Payment Required by ${merchantId}`);
                console.log(`[Personal Agent] 🤖 Using "Master Mandate" (Session Key) to auto-settle L402 micro-payment (0.05 EURC) without bothering user...`);
                
                // Simulate bridging via lightning/L402
                await new Promise(r => setTimeout(r, 1200));
                
                try {
                     console.log(`[Personal Agent] 💸 L402 Proof generated. Retrying search with Authorization header.`);
                     const retryResponse = await axios.post('http://localhost:3000/v1/ucp/search', {
                        category: intent.product_category,
                        merchant_id: merchantId
                     }, {
                        headers: { 'Authorization': 'L402 proof_secret_macaroon' }
                     });
                     
                     return retryResponse.data.offers as UcpOffer[];
                } catch (retryErr) {
                     console.error(`[Personal Agent] L402 settlement failed.`);
                     return [];
                }
            }
            return [];
        }
    }

    private scoreAndSelectOffer(offers: UcpOffer[], intent: PurchaseIntent): UcpOffer | null {
        let bestOffer: UcpOffer | null = null;
        let highestScore = -Infinity;
        const auditLogs = [];

        console.log(`\n[Personal Agent] --- Scoring Audit Trail ---`);

        for (const offer of offers) {
            if (offer.price > intent.target_budget) {
                auditLogs.push({ offer_id: offer.offer_id, status: 'REJECTED_BUDGET', price: offer.price, penalty_delay: null, total_score: null });
                continue;
            }
            if (intent.hard_constraints?.max_delivery_days && offer.estimated_delivery_days > intent.hard_constraints.max_delivery_days) {
                auditLogs.push({ offer_id: offer.offer_id, status: 'REJECTED_DELAY', price: offer.price, penalty_delay: offer.estimated_delivery_days, total_score: null });
                continue;
            }

            const pointsPrice = intent.target_budget - offer.price;
            const pointsDelay = -(offer.estimated_delivery_days * 2);
            const score = pointsPrice + pointsDelay;

            auditLogs.push({
                offer_id: offer.offer_id,
                merchant_id: offer.merchant_id,
                status: 'ELIGIBLE',
                points_price: pointsPrice,
                penalty_delay: pointsDelay,
                total_score: score
            });

            if (score > highestScore) {
                highestScore = score;
                bestOffer = offer;
            }
        }

        console.table(auditLogs);

        if (bestOffer) {
            console.log(`[Personal Agent] Selected Best Offer: ${bestOffer.offer_id} scored at ${highestScore}\n`);
        }
        return bestOffer;
    }
}

export const personalAgent = new PersonalAgent();
