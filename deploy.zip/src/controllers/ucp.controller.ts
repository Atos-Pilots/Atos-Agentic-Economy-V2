import { Request, Response } from 'express';
import { merchantAgent } from '../agents/merchant.agent';
import { flightMerchantAgent } from '../agents/flight.merchant.agent';

export class UcpController {
    
    private getAgentLogic(merchantId: string) {
        if (merchantId === merchantAgent.agentId) return merchantAgent;
        if (merchantId === flightMerchantAgent.agentId) return flightMerchantAgent;
        throw new Error('Merchant agent not found or not serving UCP on this node.');
    }

    // POST /ucp/search
    public async search(req: Request, res: Response): Promise<void> {
        try {
            const { category, merchant_id } = req.body;
            if (!category || !merchant_id) {
                res.status(400).json({ error: 'Missing category or merchant_id parameter' });
                return;
            }

            // HTTP 402 Paywall Implementation (L402)
            const authHeader = req.headers['authorization'];
            if (!authHeader || !authHeader.startsWith('L402 ')) {
                // If the Agent tries to query the DB for free, hit them with a paywall
                console.log(`[UCP Paywall] ⛔ HTTP 402: Agent attempted unpaid search on ${merchant_id}. Requesting 0.05 EURC.`);
                
                // Emitting telemetry event for Dashboard Tracking 
                const { eventBus } = require('../services/event.bus');
                eventBus.publish('payment.intent.created', { intent_id: `l402_x_${Date.now()}`, dummy: true }); // Emulate intent for L402
                
                res.setHeader('WWW-Authenticate', `L402 macaroon="mock_macaroon_string", invoice="lntb0.05_eurc"`);
                res.status(402).json({ error: 'Payment Required. Please provide an L402 token.' });
                return;
            }

            // Paywall passed! The agent paid 0.05 EURC dynamically.
            console.log(`[UCP Paywall] 🔓 L402 Proof Accepted! Agent granted commercial access.`);

            const agentLogic = this.getAgentLogic(merchant_id);
            const offers = await agentLogic.evaluateSearch(category);
            res.json({ success: true, offers });
        } catch (e: any) {
            res.status(500).json({ error: e.message });
        }
    }

    // POST /ucp/offers/select
    public async selectOffer(req: Request, res: Response): Promise<void> {
        res.json({ success: true, message: 'Offer selected and held in temporary agent memory.' });
    }

    // POST /ucp/cart/create
    public async createCart(req: Request, res: Response): Promise<void> {
        res.json({ success: true, cart_id: `cart_${Date.now()}` });
    }

    // POST /ucp/checkout/prepare
    public async prepareCheckout(req: Request, res: Response): Promise<void> {
        try {
            const { offer_id, merchant_id } = req.body;
            const agentLogic = this.getAgentLogic(merchant_id);
            const checkoutSession = await agentLogic.prepareCheckout(offer_id, {});
            res.json({ success: true, checkout_session: checkoutSession });
        } catch (e: any) {
             res.status(500).json({ error: e.message });
        }
    }

    // POST /ucp/order/confirm
    public async confirmOrder(req: Request, res: Response): Promise<void> {
        const { intent_id } = req.body;
        // In a real flow, the Personal Agent submits the UCP confirmation linked to the intent/checkout session
        if (intent_id) {
             const { eventBus } = require('../services/event.bus');
             eventBus.publish('merchant.order.confirmed', { intent_id });
        }
        res.json({ success: true, order_id: `ord_${Date.now()}`, status: 'CONFIRMED' });
    }
}
