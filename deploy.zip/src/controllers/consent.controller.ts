import { Request, Response } from 'express';
import { personalAgent } from '../agents/personal.agent';
import axios from 'axios';
import { eventBus } from '../services/event.bus';

export class ConsentController {
    
    // Store the last push notification so missed SSE connections can retrieve it
    private lastPushRequest: any = null;

    // POST /consent/request
    public async requestConsent(req: Request, res: Response): Promise<void> {
        try {
            const { amount, merchant, intent_id } = req.body;
            // Push notification to the Wallet Vault
            console.log(`[Push Server] Sending consent push notification to Wallet for ${amount} EUR to ${merchant}`);
            
            this.lastPushRequest = { amount, merchant, intent_id, timestamp: Date.now() };
            
            eventBus.publish('wallet.consent.requested', { amount, merchant, intent_id });
            res.json({ success: true, message: 'Push notification sent to Secure Wallet.' });
        } catch (e: any) {
            res.status(500).json({ error: e.message });
        }
    }

    // GET /consent/remote/pending
    public async getPendingRemoteRequests(req: Request, res: Response): Promise<void> {
        res.json({ success: true, request: this.lastPushRequest });
    }
    
    // GET /consent/pending
    public async getPendingProposals(req: Request, res: Response): Promise<void> {
        const proposals = Array.from(personalAgent.pendingProposals.values())
            .filter(p => p.status === 'user_review_pending');
            
        res.json({ success: true, proposals });
    }

    // POST /consent/approve/:id
    public async approveProposal(req: Request, res: Response): Promise<void> {
        const { id } = req.params;
        const proposal = personalAgent.pendingProposals.get(id as string);

        if (!proposal || proposal.status !== 'user_review_pending') {
            res.status(404).json({ error: 'Proposal not found or already processed' });
            return;
        }

        proposal.status = 'review_approved';
        console.log(`[Consent] User approved proposal ${id}. Transitioning to AP2 Execution...`);

        try {
            // Internal call to AP2 to execute full flow
            const authRes = await axios.post('http://localhost:3000/v1/ap2/payment-intents/auto/authorize', {
                amount: proposal.selected_offer.price,
                currency: proposal.selected_offer.currency,
                rail: proposal.suggested_rail,
                mandate_id: proposal.mandate_id
            });

            const transactionIntentId = authRes.data.intent_id;

            const ap2Res = await axios.post(`http://localhost:3000/v1/ap2/payment-intents/${transactionIntentId}/confirm`, {
                amount: proposal.selected_offer.price,
                currency: proposal.selected_offer.currency,
                rail: proposal.suggested_rail,
                mandate_id: proposal.mandate_id
            });

            // Simulate the final Merchant Callback hitting UCP
            setTimeout(() => {
                const { eventBus } = require('../services/event.bus');
                eventBus.publish('merchant.order.confirmed', { intent_id: transactionIntentId });
            }, 800);

            res.json({ success: true, status: 'APPROVED', execution: ap2Res.data });
        } catch (e: any) {
            res.status(500).json({ error: 'Failed AP2 execution: ' + e.message });
        }
    }

    // POST /consent/execute-remote
    // Used by the Distributed EUDI Wallet to auto-execute an AP2 intent when a push notification is verified via FaceID
    // The mandate was already authenticated by biometric SCA — no second authorize step needed
    public async executeRemotePayment(req: Request, res: Response): Promise<void> {
        try {
            const { mandate_id, amount, rail } = req.body;
            console.log(`[Consent] Remote EUDI Wallet (FaceID SCA) approved execution: mandate=${mandate_id}, amount=${amount}`);

            // Use a timestamped intent ID — no authorize needed (SCA already performed biometrically)
            const transactionIntentId = `remote_${Date.now()}`;
            
            // Register intent directly in the saga via event (bypasses policy engine since FaceID = SCA)
            eventBus.publish('payment.intent.created', { 
                intent_id: transactionIntentId, 
                mandate_id, 
                amount 
            });

            // Execute on AP2
            const ap2Res = await axios.post(`http://localhost:3000/v1/ap2/payment-intents/${transactionIntentId}/confirm`, {
                amount,
                currency: 'EUR',
                rail: rail || 'SEPA'
            });

            // merchant.order.confirmed is now emitted by ap2.controller after 1500ms automatically
            // so no need to duplicate it here

            res.json({ success: true, execution: ap2Res.data });
        } catch (e: any) {
             res.status(500).json({ error: 'Remote AP2 execution failed: ' + e.message });
        }
    }
}
